package gioco;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import game.BaseCard;
import game.Card;
import game.SpecialCard;

class CardTest {

	@Test
	public void baseCardTest() {
		Card card = new BaseCard("Eren", 45, "Eren.jpeg");
		assertEquals("Eren", card.getName(),"Il nome ritornato e errato");
		assertEquals("Eren.jpeg", card.getFile(),"Il nome del percorso ritornato e errato");
		assertEquals(45, card.getValue(),"Il valore della carta e errato");
		assertFalse(card.isSpecial(), "Deve ritornare false");
	}
	
	@Test
	public void specialCardTest() {
		SpecialCard card = new SpecialCard("Bonus", "johnny", "Sfere.jpeg");
		assertEquals("Bonus", card.getName(),"Il nome ritornato e errato");
		assertEquals("Sfere.jpeg", card.getFile(),"Il nome del percorso ritornato e errato");
		assertEquals("johnny", card.getPower(),"Il valore della carta e errato");
		assertTrue(card.isSpecial(), "Deve ritornare True");
	}

}
