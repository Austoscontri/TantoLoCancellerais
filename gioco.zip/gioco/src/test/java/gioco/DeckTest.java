package gioco;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import game.Card;
import game.Deck;

public class DeckTest {

    private Deck deck;
    private final String testFileName = "mazzo-comics.txt"; // Assicurati che questo file esista nel percorso specificato e contenga dati validi per il test

    @BeforeEach
    public void setUp() {
       deck = new Deck(testFileName);
    }

    @Test
    public void deckCreationTest() {
        assertEquals(15, deck.mazzo.size(), "Il mazzo dovrebbe contenere esattamente 15 carte dopo la creazione");
    }

    @Test
    public void shuffleDeckTest() {
        // Copia del mazzo prima della mischiata
        ArrayList<Card> copyBeforeShuffle = new ArrayList<>(deck.mazzo);
        deck.shuffleDeck();
        // Verifica che l'ordine delle carte sia cambiato
        assertNotEquals(copyBeforeShuffle, deck.mazzo, "Il mazzo dovrebbe essere stato mischiato e quindi cambiato di ordine");
    }

    @Test
    public void getFirstCardTest() {
        int initialSize = deck.mazzo.size();
        Card firstCard = deck.getFirstCard();
        assertNotNull(firstCard, "getFirstCard non dovrebbe ritornare null se il mazzo non è vuoto");
        assertEquals(initialSize, deck.mazzo.size(), "Dovrebbe essere stata rimossa una carta dal mazzo");
        
        // Testa il comportamento quando il mazzo è vuoto
        deck.mazzo.clear(); // Svuota il mazzo
        assertNull(deck.getFirstCard(), "getFirstCard dovrebbe ritornare null se il mazzo è vuoto");
    }
}
