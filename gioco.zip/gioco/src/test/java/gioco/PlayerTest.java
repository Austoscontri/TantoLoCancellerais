package gioco;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import game.Deck;
import game.Giocatore;
import game.IA;

public class PlayerTest {

    private Giocatore giocatore;
    private IA ia;
    private Deck mockDeck;

    @BeforeEach
    public void setUp() {

        mockDeck = new Deck("mazzo-anime.txt");
        giocatore = new Giocatore("Giocatore 1", mockDeck);
        ia = new IA("IA 1", mockDeck);
    }

    @Test
    public void testGetName() {
        assertEquals("Giocatore 1", giocatore.getName(), "Il nome del giocatore non corrisponde.");
        assertEquals("IA 1", ia.getName(), "Il nome dell'IA non corrisponde.");
    }

    @Test
    public void testAddPoints() {
        giocatore.addPoints(10);
        assertEquals(10, giocatore.getPoints(), "I punti aggiunti al giocatore non corrispondono.");

        ia.addPoints(5);
        assertEquals(5, ia.getPoints(), "I punti aggiunti all'IA non corrispondono.");
    }

    @Test
    public void testResetPoints() {
        giocatore.addPoints(10);
        giocatore.resetPoints();
        assertEquals(0, giocatore.getPoints(), "I punti del giocatore non sono stati resettati correttamente.");

        ia.addPoints(5);
        ia.resetPoints();
        assertEquals(0, ia.getPoints(), "I punti dell'IA non sono stati resettati correttamente.");
    }

    @Test
    public void testAddTurnScore() {
        giocatore.addTurnScore();
        assertEquals(1, giocatore.getTurnScore(), "Il punteggio del turno per il giocatore non è stato incrementato correttamente.");

        ia.addTurnScore();
        assertEquals(1, ia.getTurnScore(), "Il punteggio del turno per l'IA non è stato incrementato correttamente.");
    }
    
    @Test
    public void testGiocatorePlayCardNull() {
        assertNull(giocatore.playCard(0), "playCard dovrebbe restituire null in quanto la mano e vuota");
    }

    @Test
    public void testIAPlayCardNull() {
        assertNull(ia.playCard(0), "playCard dovrebbe restituire null in quanto la mano e vuota");
    }
    
    @Test
    public void testGiocatorePlayCard() {
    	giocatore.mano.refillHand(mockDeck);
        assertNotNull(giocatore.playCard(1), "playCard dovrebbe restituire una carta non null in quanto la mano e piena");
    }

    @Test
    public void testIAPlayCard() {
    	ia.mano.refillHand(mockDeck);
        assertNotNull(ia.playCard(1), "playCard dovrebbe restituire una carta non null in quanto la mano e piena");
    }
    
}
