package game;

public class Giocatore extends Player {

    public Giocatore(String nome, Deck deck) {
        super(nome, deck);
    }

}
