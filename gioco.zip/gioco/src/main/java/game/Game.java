package game;

public interface Game {

    void matchStart();
}
